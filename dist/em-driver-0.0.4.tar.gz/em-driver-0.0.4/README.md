# em-driver

This is a simple package. It will help you to build SQLite3 databases in python without having to define the SQl schema yourself.
Have fun!
